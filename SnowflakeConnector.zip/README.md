# SnowflakeConnectorForSentinel
This repository holds the Python script for Snowflake connector for Sentinel
